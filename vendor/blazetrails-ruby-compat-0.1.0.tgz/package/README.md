# @blazetrails/ruby-compat

Ruby core and stdlib primitives that trails calls but Rails does not define.

Rails is written against Ruby. A port of Rails therefore needs pieces of Ruby
itself — `Object#blank?`'s notion of whitespace, `String#succ`'s carry,
`Hash#fetch`'s stored-`nil` semantics, `Rational` canonicalization — and those
pieces have no Rails counterpart to mirror. Historically they accumulated inside
`@blazetrails/activesupport`, which inverted the real dependency: ActiveSupport
is a Rails gem that _uses_ Ruby, not the place Ruby lives. This package is where
they belong instead.

Its upstream is [ruby/ruby](https://github.com/ruby/ruby), vendored at
`vendor/ruby/v3.3.11/` (RFC 0129). Read the C or the Ruby there before writing
anything here, the same way every other package reads `vendor/rails/` first.

Every other package depends on this one, and it depends on nothing in the
workspace (rule 4). It is not a general Ruby runtime: a member exists only
because some other package calls it (rule 1).

## Using it

Most users never import it directly; the framework packages do. What a trails
application does touch is the host-adapter layer and a few Ruby values that
cross the API boundary:

```ts
import { Range, env, setEnv } from "@blazetrails/ruby-compat";

new Range(1, 10).isInclude(5); // true: Ruby's Range#include?
setEnv("TRAILS_ENV", "test"); // ENV["TRAILS_ENV"] = "test", through the process adapter
env.TRAILS_ENV; // "test"
```

The subpath exports `./include`, `./method-missing-proxy`, `./name-error` and
`./range` exist for the packages that need those modules without loading the
barrel.

## What is here

About 110 modules, grouped by the MRI area they port:

| area                        | modules                                                                                                                                                                                                                                                                                 |
| --------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Object model                | `include` / `extend` / `prepend` (`Module#include` and friends, `included` / `extended` hooks), `Method`, `rbObjRespondTo` / `basicObjRespondTo`, `rbFSend`, `rbModPrivate` / `rbModProtected` visibility, `rbObjSingletonClass`, `methodMissingPrototype`, `ObjectSpace`               |
| Equality, hashing, ordering | `rbEqual` / `rbEql` / `rbEqq`, `rbHash`, `Comparable` (`cmp`, `isBetween`, …), `Enumerable`, `Enumerator` / `toEnum`                                                                                                                                                                    |
| Core values                 | `Range`, `Rational`, `BigDecimal`, `NilClass`, numeric helpers (`round`, `toI`, `anybits`), `Kernel#Integer` / `Float` / `format` / `rand` / `catch`                                                                                                                                    |
| String, Symbol, Regexp      | `succ`, `chomp`, `scrub`, `byteslice`, `split`, `inspect`, `force_encoding`, `Encoding`, `StringScanner`, `StringIO`, `MatchData`, `regexpEscape`, Symbol helpers                                                                                                                       |
| Array, Hash                 | Ruby `Array` methods (`pack`, `unpack1`, `slice`, `uniq`, …) and `Hash` methods with Ruby semantics (`fetch`, `merge`, `except`, default procs, …)                                                                                                                                      |
| Exceptions                  | `Exception`, `StandardError`, `ArgumentError`, `NameError`, `NoMethodError`, `TypeError`, `KeyError`, `FrozenError`, `ZeroDivisionError`, …, and `Location` / `excBacktraceLocations` for backtraces                                                                                    |
| Concurrency                 | `Monitor` / `synchronize` / `MonitorMixin`, `Mutex`, `Thread`, `Fiber`, `ThreadPoolExecutor`                                                                                                                                                                                            |
| Stdlib                      | `Marshal`, `Psych`, `PP` / `PrettyPrint`, `Open3`, `File`, `Dir`, `FileUtils`, `IO`, `Tempfile`, `JSON`, `Base64`, `Digest`, `OpenSSL` (`Cipher`, `HMAC`), `SecureRandom`, `Zlib`, `URI`, `IPAddr`, `Gem`, `RbConfig`, `Process`                                                        |
| Host adapters               | Pluggable backends for the host runtime: `registerFsAdapter`, `registerCryptoAdapter`, `registerProcessAdapter`, `registerZlibAdapter`, `registerHttpAdapter`, `registerOsAdapter`, `registerChildProcessAdapter`, `registerAsyncContextAdapter`. Node implementations are the default. |

`src/index.ts` is the complete list.

### Call sites for the first exports

The table below covers a subset of the exports, with the call site that
justifies each (rule 1). Extending it to
every export is part of `ruby-compat-rule-1-call-site-gate` (RFC 0154), which
also puts rule 1 under a gate.

| export                                                                  | MRI anchor                                                               | call sites                                                                                                                                                                                                                                                                                                                                                                                                    |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `regexpEscape`                                                          | `re.c:4144` `rb_reg_s_quote`                                             | `activerecord/src/support/quote-regex.ts`, `run-token.ts`, `trailties/src/generators/trails-actions.ts`                                                                                                                                                                                                                                                                                                       |
| `rbRegMatchP`                                                           | `re.c:3811` `rb_reg_match_p`                                             | `activerecord/src/connection-adapters/abstract/schema-definitions.ts`, `actionpack/src/action-dispatch/http/request.ts`                                                                                                                                                                                                                                                                                       |
| `rbRegSUnion`                                                           | `re.c:4192` `rb_reg_s_union`                                             | `activerecord/src/connection-adapters/abstract-adapter.ts` (`buildReadQueryRegexp`), `sqlite3-adapter.ts` (`tableStructureSql`)                                                                                                                                                                                                                                                                               |
| `Pathname`                                                              | `ext/pathname/pathname.c:1511` `rb_cPathname`                            | `activesupport/src/message-pack/extensions.ts` (`Extensions.install`, ext type 15)                                                                                                                                                                                                                                                                                                                            |
| `rbRegInitStr`, `rbRegToS(re, "onig")`                                  | `re.c:3360` `rb_reg_init_str`, `re.c:322` `option_to_str`                | `activesupport/src/message-pack/extensions.ts` (`Extensions.install`, ext type 16)                                                                                                                                                                                                                                                                                                                            |
| `Range`                                                                 | `range.c:31` `rb_cRange`                                                 | `activesupport/src/core-ext/range/*.ts`, `activemodel/src/validations/{clusivity,length,numericality}.ts`                                                                                                                                                                                                                                                                                                     |
| `rbEqual`                                                               | `object.c:147` `rb_equal`                                                | `ruby-compat/lib/range.ts` (`Range#==`)                                                                                                                                                                                                                                                                                                                                                                       |
| `succ`                                                                  | `string.c:4868` `rb_str_succ`                                            | `ruby-compat/lib/range.ts` (string ranges), `arel`                                                                                                                                                                                                                                                                                                                                                            |
| `Rational`                                                              | `rational.c:481` `nurat_s_canonicalize_internal`                         | `activemodel/src/type/{decimal,date-time}.ts`, `type/helpers/time-value.ts`, `activesupport/src/{time-with-zone.ts,core-ext/date-time/calculations.ts,message-pack/extensions.ts}`, `activerecord/src/connection-adapters/mysql/quoting.ts`, `date/lib/date.ts`                                                                                                                                               |
| `rational`                                                              | `rational.c:2691` `nurat_s_convert`                                      | `activesupport/src/core-ext/date-time/calculations.ts:274,290,306` (`end_of_day` / `end_of_hour` / `end_of_minute`), `message-pack/extensions.ts` (`read_rational`)                                                                                                                                                                                                                                           |
| `ZeroDivisionError`                                                     | `numeric.c:206` `rb_num_zerodiv`                                         | `activesupport/src/message-pack/extensions.ts` (`readRational` raises it on a zero denominator)                                                                                                                                                                                                                                                                                                               |
| `Enumerator`                                                            | `enumerator.c:411` `enumerator_init`                                     | `activesupport/src/hash-with-indifferent-access.ts` (`select` / `reject` block-less arm)                                                                                                                                                                                                                                                                                                                      |
| `toEnum`                                                                | `enumerator.c:383` `obj_to_enum`                                         | `activesupport/src/hash-with-indifferent-access.ts` (`to_enum(:select)`, `to_enum(:reject)`)                                                                                                                                                                                                                                                                                                                  |
| `Lazy`                                                                  | `enumerator.c:1804` `lazy_initialize`                                    | `rake/src/file-list.ts` (`lazy` / `chain`, `file_list.rb:44`)                                                                                                                                                                                                                                                                                                                                                 |
| `Chain`                                                                 | `enumerator.c:3176` `enum_chain_initialize`                              | `rake/src/file-list.ts` (`lazy` / `chain`, `file_list.rb:44`)                                                                                                                                                                                                                                                                                                                                                 |
| `enumerableLazy`                                                        | `enumerator.c:1937` `enumerable_lazy`                                    | `rake/src/file-list.ts` (`lazy` / `chain`, `file_list.rb:44`)                                                                                                                                                                                                                                                                                                                                                 |
| `enumChain`                                                             | `enumerator.c:3371` `enum_chain`                                         | `rake/src/file-list.ts` (`lazy` / `chain`, `file_list.rb:44`)                                                                                                                                                                                                                                                                                                                                                 |
| `isSymbol`                                                              | `symbol.c:954` `rb_sym2str`                                              | `i18n/src/backend/{base,fallbacks,simple,key-value}.ts`, `activemodel/src/validations/numericality.ts`                                                                                                                                                                                                                                                                                                        |
| `symbolToS`                                                             | `symbol.c:954` `rb_sym2str`                                              | `i18n/src/backend/base.ts:242,444`                                                                                                                                                                                                                                                                                                                                                                            |
| `toSym`                                                                 | `symbol.c:862` `rb_str_intern`                                           | `activerecord/src/associations/preloader/branch.ts` (`Branch#initialize`'s `association.to_sym`, `rescue NoMethodError`)                                                                                                                                                                                                                                                                                      |
| `Location`                                                              | `vm_backtrace.c:1345` `rb_cBacktraceLocation`                            | `actionpack/src/action-dispatch/middleware/exception-wrapper.ts` (`build_backtrace`'s `loc.label`, `SourceMapLocation#spot`)                                                                                                                                                                                                                                                                                  |
| `excBacktraceLocations`                                                 | `error.c:1789` `exc_backtrace_locations`                                 | `actionview/src/template/error.ts` (`Template::Error#backtrace_locations`), `exception-wrapper.ts` (`build_backtrace`)                                                                                                                                                                                                                                                                                        |
| `StringScanner`                                                         | `ext/strscan/strscan.c:681` `strscan_scan`                               | `actionpack/src/action-dispatch/journey/gtg/simulator.ts` (`Simulator#memos`)                                                                                                                                                                                                                                                                                                                                 |
| `rbObjInstanceVariables`                                                | `variable.c:2259` `rb_obj_instance_variables`                            | `ruby-compat/lib/psych/visitors/yaml-tree.ts` (`YAMLTree#dump_ivars`)                                                                                                                                                                                                                                                                                                                                         |
| `rbObjIvarGet`                                                          | `object.c:2880` `rb_obj_ivar_get`                                        | `ruby-compat/lib/psych/visitors/yaml-tree.ts` (`YAMLTree#dump_ivars`)                                                                                                                                                                                                                                                                                                                                         |
| `rbObjIvarSet`                                                          | `object.c:2914` `rb_obj_ivar_set_m`                                      | `ruby-compat/lib/psych/visitors/to-ruby.ts` (`ToRuby#init_with`)                                                                                                                                                                                                                                                                                                                                              |
| `rbDeclareIvar`                                                         | none: the ivar's JS field                                                | `activemodel/src/{attribute-set,attribute-set/builder,type/integer}.ts`                                                                                                                                                                                                                                                                                                                                       |
| `Struct`                                                                | `struct.c:643` `rb_struct_s_def`                                         | `arel/src/attributes/attribute.ts` (`Attribute < Struct.new :relation, :name`)                                                                                                                                                                                                                                                                                                                                |
| `stringSuperclass`                                                      | `string.c:12119` `rb_cString`                                            | `arel/src/nodes/sql-literal.ts` (`SqlLiteral < String`)                                                                                                                                                                                                                                                                                                                                                       |
| `rbObjClass`                                                            | `object.c:265` `rb_obj_class`                                            | `arel/src/visitors/visitor.ts` (`visit`'s `dispatch[object.class]` and `object.class.ancestors`, `visitor.rb:28,40`)                                                                                                                                                                                                                                                                                          |
| `rbProcCall`                                                            | `proc.c:990` `rb_proc_call`                                              | `actioncable/src/connection/base.ts` (`new_tagged_logger`'s `tag.call(request)`, `connection/base.rb:262-266`)                                                                                                                                                                                                                                                                                                |
| `rbModName`                                                             | `variable.c:122` `rb_mod_name`                                           | `arel/src/visitors/visitor.ts` (`dispatch_cache`'s `klass.name`), `arel/src/nodes/bound-sql-literal.ts` (`inspect`), `ruby-compat/lib/psych/visitors/yaml-tree.ts` (`YAMLTree#visit_Object`'s `o.class.name`), `activesupport/src/delegation.ts` (`delegate`'s `to.name`), `activesupport/src/core-ext/name-error.ts` (`real_mod_name`)                                                                       |
| `rbSetClassPathString`                                                  | `variable.c:407` `rb_set_class_path_string`                              | `arel/src/nodes/*.ts`, `arel/src/{table,select-manager,attributes/attribute}.ts`, `arel/src/visitors/*.ts`, `activemodel/src/attribute.ts`                                                                                                                                                                                                                                                                    |
| `rbGvGet` / `rbGvSet`                                                   | `variable.c:984` `rb_gv_get`, `:970` `rb_gv_set`                         | `thor/src/thor.ts` (`$thor_runner \|\|= false`), `thor/base.ts` (`handle_no_command_error`'s default)                                                                                                                                                                                                                                                                                                         |
| `isRegisteredConstant`                                                  | `variable.c:3527` `rb_const_defined` on `rb_cObject`                     | `activesupport/src/inflector.ts` (`constantize`), `trailties/src/generators/base.ts` (`class_collisions`, `module_namespacing`)                                                                                                                                                                                                                                                                               |
| `registeredConstant`                                                    | `variable.c:3210` `rb_const_get` on `rb_cObject`                         | `activesupport/src/inflector.ts` (`constantize`'s `Object.const_get`)                                                                                                                                                                                                                                                                                                                                         |
| `resetConstants`                                                        | none: empties the table between tests                                    | `globalid/src/*.test.ts`, `activesupport/src/{inflector,core-ext/string-ext}.test.ts`                                                                                                                                                                                                                                                                                                                         |
| `Psych.dump` (`./psych`)                                                | `ext/psych/lib/psych.rb:505` `Psych.dump`                                | `activerecord/src/yaml-serialization.test.ts`, `store.test.ts` (`YAML.dump`); `ruby-compat/lib/psych/core-ext.ts` (`toYaml`)                                                                                                                                                                                                                                                                                  |
| `Psych.unsafeLoad` (`./psych`)                                          | `ext/psych/lib/psych.rb:271` `Psych.unsafe_load`                         | `activerecord/src/yaml-serialization.test.ts` (`YAML.unsafe_load`)                                                                                                                                                                                                                                                                                                                                            |
| `Psych.safeDump` (`./psych`)                                            | `ext/psych/lib/psych.rb:578` `safe_dump`                                 | `activerecord/src/coders/yaml-column.ts` (`yaml_column.rb:19-23`)                                                                                                                                                                                                                                                                                                                                             |
| `Psych.Visitors.RestrictedYAMLTree` (`./psych`)                         | `psych/visitors/yaml_tree.rb:540`                                        | `Psych.safeDump` (`psych.rb:584`)                                                                                                                                                                                                                                                                                                                                                                             |
| `toYaml` (`./yaml`)                                                     | `ext/psych/lib/psych/core_ext.rb:12` `to_yaml`                           | `activerecord/src/relation.ts` (`relations_test.rb:79-82`)                                                                                                                                                                                                                                                                                                                                                    |
| `Psych.loadFile` / `Psych.unsafeLoadFile` (`./psych`)                   | `ext/psych/lib/psych.rb:647,669`                                         | no non-test caller until `configuration_file.rb:26`, i18n `backend/base.rb:264` and `change_generator.rb:124` converge                                                                                                                                                                                                                                                                                        |
| `Psych.Omap` (`./psych`)                                                | `ext/psych/lib/psych/omap.rb:3`                                          | `psych/visitors/to-ruby.ts` (`to_ruby.rb:149,292`), `yaml-tree.ts` (`yaml_tree.rb:139`)                                                                                                                                                                                                                                                                                                                       |
| `Psych.load` / `Psych.safeLoad` (`./psych`)                             | `ext/psych/lib/psych.rb:322,368` `safe_load` / `load`                    | `activerecord/src/coders/yaml-column.ts` (`yaml_column.rb:37-41`), `activesupport/src/xml-mini.ts` (`xml_mini.rb:83`), until each converges onto `Psych`                                                                                                                                                                                                                                                      |
| `Psych.loadTags` / `Psych.dumpTags` (`./psych`)                         | `ext/psych/lib/psych.rb:741-742` `load_tags` / `dump_tags`               | `activerecord/src/active-record.ts` (`YAML.load_tags[...]`, `active_record.rb:570-573`)                                                                                                                                                                                                                                                                                                                       |
| `Psych.domainTypes` / `Psych.addBuiltinType` (`./psych`)                | `ext/psych/lib/psych.rb:682-686,738` `domain_types` / `add_builtin_type` | `ruby-compat/lib/psych/visitors/to-ruby.ts` (`ToRuby#accept`, `to_ruby.rb:35-50`)                                                                                                                                                                                                                                                                                                                             |
| `Psych.DisallowedClass` (`./psych`)                                     | `ext/psych/lib/psych/exception.rb:23`                                    | `activerecord/src/coders/yaml-column.ts` (`SafeCoder#dump`)                                                                                                                                                                                                                                                                                                                                                   |
| `Psych.Coder` (`./psych`)                                               | `ext/psych/lib/psych/coder.rb:9`                                         | `activerecord/src/legacy-yaml-adapter.ts` (`LegacyYamlAdapter.convert`), `activemodel/src/attribute.ts` (`init_with` / `encode_with`)                                                                                                                                                                                                                                                                         |
| `Psych.ClassLoader` / `.Restricted` (`./psych`)                         | `ext/psych/lib/psych/class_loader.rb:6,76`                               | `ruby-compat/lib/psych/visitors/to-ruby.ts` (`ToRuby.create`), `yaml-tree.ts` (`YAMLTree.create`); `Restricted` has no non-test caller until `psych-load-and-safe-load`                                                                                                                                                                                                                                       |
| `Psych.ScalarScanner` (`./psych`)                                       | `ext/psych/lib/psych/scalar_scanner.rb:7`                                | `ruby-compat/lib/psych/visitors/to-ruby.ts` (`ToRuby.create`), `yaml-tree.ts` (`YAMLTree.create`)                                                                                                                                                                                                                                                                                                             |
| `Psych.Visitors.NoAliasRuby` (`./psych`)                                | `ext/psych/lib/psych/visitors/to_ruby.rb:430`                            | no non-test caller until `psych-load-and-safe-load` (`Psych.safe_load`, `psych.rb:332`)                                                                                                                                                                                                                                                                                                                       |
| `Psych.BadAlias` / `AliasesNotEnabled` / `AnchorNotDefined` (`./psych`) | `ext/psych/lib/psych/exception.rb:6-21`                                  | `ruby-compat/lib/psych/visitors/to-ruby.ts` (`visit_Psych_Nodes_Alias`, `to_ruby.rb:327-328,431-433`)                                                                                                                                                                                                                                                                                                         |
| `YAML` (`./yaml`)                                                       | `lib/yaml.rb:20` `YAML = Psych`                                          | `activerecord/src/active-record.ts` (`active_record.rb:570-573`)                                                                                                                                                                                                                                                                                                                                              |
| `parse` / `stringify` (`./psych-adapter`)                               | `ext/psych/lib/psych.rb:13` `require 'psych.so'` (the libyaml seam)      | `activerecord/src/coders/yaml-column.ts`, `connection-adapters/schema-cache.ts`, `abstract/database-statements.ts`, `actionview/src/helpers/debug-helper.ts`, `activesupport/src/{configuration-file,encrypted-configuration,xml-mini}.ts`, until each converges onto `Psych`                                                                                                                                 |
| `registerPsychAdapter` / `psychAdapterConfig` (`./psych-adapter`)       | `ext/psych/lib/psych.rb:13` `require 'psych.so'` (the libyaml seam)      | `website/src/lib/frontiers/{runtime,sandbox-sw}.ts`                                                                                                                                                                                                                                                                                                                                                           |
| `rbDefineMethod`                                                        | `class.c:2134` `rb_define_method`                                        | `activesupport/src/core-ext/object/blank.ts` (`String#blank?`, `blank.rb:153`)                                                                                                                                                                                                                                                                                                                                |
| `rbModDefineMethod`                                                     | `proc.c:2325` `rb_mod_define_method`                                     | `activerecord/src/autosave-association.ts` (`define_non_cyclic_method`, `autosave_association.rb:162`), `integration.ts` (`to_param`, `integration.rb:151`), `enum.ts` (`_enum`'s `singleton_class.define_method(name.pluralize)`, `enum.rb:232`), `secure-token.ts` (`has_secure_token`, `secure_token.rb:53`), `scoping/named.ts` (`scope`, `scoping/named.rb:174,180`)                                     |
| `first`                                                                 | `array.c:1901` `ary_first`, `enum.c:1284` `enum_first`                   | `activerecord/src/connection-adapters/abstract-mysql-adapter.ts` (`build_insert_sql`'s `insert.keys.first` over a `Set`, `abstract_mysql_adapter.rb:640`)                                                                                                                                                                                                                                                     |
| `aryCount`                                                              | `array.c:6275` `rb_ary_count`                                            | `activerecord/src/associations/has-many-through-association.ts` (`delete_records`'s `scope.destroy_all.count(&:destroyed?)`)                                                                                                                                                                                                                                                                                  |
| `aryJoin`                                                               | `array.c:2806` `rb_ary_join`                                             | `activerecord/src/connection-adapters/postgresql/database-statements.ts` and `mysql/database-statements.ts` (`build_explain_clause`'s `options.join(", ").upcase` over Symbols, `postgresql/database_statements.rb:148`)                                                                                                                                                                                      |
| `Method#owner`                                                          | `proc.c:1988` `method_owner`                                             | `activerecord/src/scoping/default.ts` (`build_default_scope`'s `method(:default_scope).owner`, `scoping/default.rb:149`)                                                                                                                                                                                                                                                                                      |
| `AsyncEnumerable`                                                       | `enum.c:5047` `Init_Enumerable` (`enum_sum` `:4753`, `enum_to_a` `:711`) | `activerecord/src/relation/batches/batch-enumerator.ts` (`include Enumerable`, `batch_enumerator.rb:6`, over an awaiting `each`)                                                                                                                                                                                                                                                                              |
| `Enumerable.sum`                                                        | `enum.c:4753` `enum_sum`                                                 | `activesupport/src/enumerable-utils.ts` (`sum`)                                                                                                                                                                                                                                                                                                                                                               |
| `reduce`                                                                | `enum.c:1005` `enum_inject` (`reduce`, `:5085`)                          | `activerecord/src/associations/preloader/through-association.ts` (`source_records_by_owner` / `through_records_by_owner`'s `.reduce(:merge)`, `through_association.rb:89,93`)                                                                                                                                                                                                                                 |
| `Hash#merge`                                                            | `hash.c:4144` `rb_hash_merge`                                            | `ruby-compat/lib/enumerable.ts` (`reduce`'s `:merge` send to the preloader's `records_by_owner` Hashes)                                                                                                                                                                                                                                                                                                       |
| `aryReject`                                                             | `array.c:4301` `rb_ary_reject`                                           | `activerecord/src/validations/associated.ts` (`validate_each`'s `Array(value).reject { ... }`, whose block awaits `valid?`)                                                                                                                                                                                                                                                                                   |
| `deleteAt`                                                              | `array.c:4072` `rb_ary_delete_at_m`                                      | `actionpack/src/action-controller/metal/params-wrapper.ts` (`Options#_default_wrap_model`'s `namespaces.delete_at(-2)`)                                                                                                                                                                                                                                                                                       |
| `rbStrGetbyte`                                                          | `string.c:6141` `rb_str_getbyte`                                         | `actionpack/src/action-controller/metal/request-forgery-protection.ts` (`xor_byte_strings`'s `s2.setbyte(i, s1.getbyte(i) ^ s2.getbyte(i))`)                                                                                                                                                                                                                                                                  |
| `rbStrSetbyte`                                                          | `string.c:6166` `rb_str_setbyte`                                         | `actionpack/src/action-controller/metal/request-forgery-protection.ts` (`xor_byte_strings`'s `s2.setbyte(i, s1.getbyte(i) ^ s2.getbyte(i))`)                                                                                                                                                                                                                                                                  |
| `intXor`                                                                | `numeric.c:5055` `int_xor`                                               | `actionpack/src/action-controller/metal/request-forgery-protection.ts` (`xor_byte_strings`'s `s1.getbyte(i) ^ s2.getbyte(i)`)                                                                                                                                                                                                                                                                                 |
| `aryIncludes`                                                           | `array.c:5222` `rb_ary_includes`                                         | `activemodel/src/validations/acceptance.ts` (`setup!`'s `klass.included_modules.include?(define_attributes)`, `acceptance.rb:20`)                                                                                                                                                                                                                                                                             |
| `isNil`                                                                 | `object.c:4425` `rb_true`, `object.c:4371` `rb_false`                    | `arel/src/nodes/bind-param.ts` (`BindParam#nil?`'s `value.nil?`, `bind_param.rb:23`); `arel/src/nodes/casted.ts` (`Casted#nil?` / `Quoted#nil?`, `casted.rb:15,41`); `arel/src/visitors/to-sql.ts` (`right.nil?` in `visit_Arel_Nodes_Equality` / `NotEqual` / `IsNotDistinctFrom` / `IsDistinctFrom`, `to_sql.rb:642-690`); `arel/src/predications.ts` (`open_ended?`'s `value.nil?`, `predications.rb:257`) |
| `partition`                                                             | `enum.c:1102` `enum_partition`                                           | `activerecord/src/associations/join-dependency.ts` (`walk`'s `.partition(&:first)`)                                                                                                                                                                                                                                                                                                                           |
| `groupBy`                                                               | `enum.c:1157` `enum_group_by`                                            | `activemodel/src/errors.ts` (`group_by_attribute`'s `@errors.group_by(&:attribute)`, `errors.rb:289-291`)                                                                                                                                                                                                                                                                                                     |
| `each`                                                                  | `array.c:2532` `rb_ary_each`                                             | `activemodel/src/attribute-set/builder.ts` (`LazyAttributeHash#each_key`'s `keys.each(&block)`, `attribute_set/builder.rb:131`)                                                                                                                                                                                                                                                                               |
| `keys`                                                                  | `hash.c:3584` `rb_hash_keys`                                             | `activemodel/src/attribute-set/builder.ts` (`LazyAttributeSet#keys`' `values.keys \| types.keys \| @attributes.keys`, `attribute_set/builder.rb:37`)                                                                                                                                                                                                                                                          |
| `last`                                                                  | `array.c:1914` `rb_ary_last`                                             | `activerecord/src/relation/finder-methods.ts` (`find_last`'s `limit ? records.last(limit) : records.last`, `finder_methods.rb:634-636`)                                                                                                                                                                                                                                                                       |
| `toH`                                                                   | `array.c:2988` `rb_ary_to_h`                                             | `activerecord/src/connection-adapters/mysql/schema-statements.ts` (`indexes`' `index[-1].to_h { \|name\| … }`, `mysql/schema_statements.rb:58`)                                                                                                                                                                                                                                                               |
| `rbStrPartition`                                                        | `string.c:10574` `rb_str_partition`                                      | `activerecord/src/connection-adapters/sqlite3-adapter.ts` (`table_structure_sql`'s `result.partition(UNQUOTED_OPEN_PARENS_REGEX).last`, `sqlite3_adapter.rb:781-782`)                                                                                                                                                                                                                                         |
| `Hash#replace`                                                          | `hash.c:2967` `rb_hash_replace`                                          | `thor/src/core-ext/hash-with-indifferent-access.ts` (`replace`'s `super`, `hash_with_indifferent_access.rb:73`)                                                                                                                                                                                                                                                                                               |
| `slice` (Hash receiver)                                                 | `hash.c:2651` `rb_hash_slice`                                            | `thor/src/core-ext/hash-with-indifferent-access.ts` (`slice`'s `super`, `hash_with_indifferent_access.rb:42`)                                                                                                                                                                                                                                                                                                 |
| `update` / `mergeBang` (Hash receiver)                                  | `hash.c:4028` `rb_hash_update`                                           | `thor/src/core-ext/hash-with-indifferent-access.ts` (`to_hash`'s `Hash.new(default).merge!(self)`, `hash_with_indifferent_access.rb:78`)                                                                                                                                                                                                                                                                      |
| `fetch` (forwarded arguments)                                           | `hash.c:2176` `rb_hash_fetch_m`                                          | `thor/src/core-ext/hash-with-indifferent-access.ts` (`fetch`'s `super(convert_key(key), *args)`, `hash_with_indifferent_access.rb:38`)                                                                                                                                                                                                                                                                        |
| `dup` (Hash subclass)                                                   | `hash.c:1584` `rb_hash_dup`                                              | `thor/src/core-ext/hash-with-indifferent-access.ts` (`except`'s `dup.tap`, `merge`'s `dup.merge!`, `hash_with_indifferent_access.rb:32,54`)                                                                                                                                                                                                                                                                   |
| `objRespondToMissing`                                                   | `vm_method.c:3009` `obj_respond_to_missing`                              | `actionpack/src/action-dispatch/routing/routes-proxy.ts` (`respond_to_missing?`'s `super`, `routes_proxy.rb:27`); `actionpack/src/action-dispatch/http/mime-type.ts` (`Mime::Type#respond_to_missing?`'s `super`, `mime_type.rb:345`)                                                                                                                                                                         |
| `Concurrent` (`Concurrent::Map`)                                        | `hash.c:1782` `rb_hash_initialize`                                       | `activemodel/src/attribute-methods.ts` (`attribute_method_patterns_cache`'s `Concurrent::Map.new(initial_capacity: 4)` and `compute_if_absent`, `attribute_methods.rb:417-424`)                                                                                                                                                                                                                               |
| `Concurrent::AtomicBoolean`                                             | `thread_sync.c:697` `rb_mutex_synchronize_m`                             | `activerecord/src/asynchronous-queries-tracker.ts` (`Session#initialize`, `active?`, `finalize`, `asynchronous_queries_tracker.rb:8-28`)                                                                                                                                                                                                                                                                      |
| `Concurrent::ReadWriteLock`                                             | `thread_sync.c:1581` `rb_condvar_wait`                                   | `activerecord/src/asynchronous-queries-tracker.ts` (`Session#initialize`, `synchronize`, `finalize`, `asynchronous_queries_tracker.rb:8-28`)                                                                                                                                                                                                                                                                  |
| `Concurrent::AtomicFixnum`                                              | `thread_sync.c:697` `rb_mutex_synchronize_m`                             | `actioncable` (`Channel::Base`'s deferred-confirmation counter, `channel/base.rb:164,240,245,249`)                                                                                                                                                                                                                                                                                                            |
| `Concurrent::TimerTask`                                                 | `thread_sync.c:626` `rb_mutex_sleep`                                     | `actioncable` (`StreamEventLoop#timer`, `connection/stream_event_loop.rb:20`; `PeriodicTimers#stop_periodic_timers`, `channel/periodic_timers.rb:73`)                                                                                                                                                                                                                                                         |
| `ThreadPoolExecutor` (`name:`, `:abort`, `<<`, `shuttingdown?`)         | `thread.c:897` `thread_s_new`                                            | `actioncable` (`Server::Worker`, `server/worker.rb:22-37`; `StreamEventLoop`, `connection/stream_event_loop.rb:27,70-74`)                                                                                                                                                                                                                                                                                     |
| `globalIoExecutor` (`Concurrent.global_io_executor`)                    | `thread.c:897` `thread_s_new`                                            | `actioncable` tests (`test_helper.rb:22`, `stubs/test_server.rb:35`)                                                                                                                                                                                                                                                                                                                                          |
| `BasicSocket` / `TCPSocket`                                             | `ext/socket/basicsocket.c:746`, `ext/socket/tcpsocket.c:108`             | `rack/src/handler/node.ts` (`rack.hijack`, which `Rack::Lint#check_hijack` requires to answer an `IO`, `rack/lint.rb:591-603`)                                                                                                                                                                                                                                                                                |
| `Marshal`                                                               | `marshal.c:2555` `rb_define_module("Marshal")`                           | `activerecord/src/connection-adapters/schema-cache.ts` (`schema_cache.rb:233,409`) and `actionview/src/helpers/debug-helper.ts` (`debug_helper.rb:29`); byte fixtures regenerate with `ruby packages/ruby-compat/test/marshal.fixtures.rb`; `Marshal.load` resolves a class path through `rbPathToClass`, so a loaded class is one `constSet` seated                                                          |
| `rbFSystem`                                                             | `process.c:4841` `rb_f_system`                                           | `Thor::Actions#run` (`vendor/thor/v1.3.2/lib/thor/actions.rb:268`), ported by `port-thor-actions-run-run-ruby-script-and-thor`                                                                                                                                                                                                                                                                                |
| `exec`                                                                  | `process.c:3015` `rb_f_exec`                                             | `activerecord/src/connection-adapters/abstract-adapter.ts` (`find_cmd_and_exec`, `abstract_adapter.rb:114`)                                                                                                                                                                                                                                                                                                   |
| `encode`, `UndefinedConversionError`                                    | `transcode.c:2906` `str_encode`, `transcode.c:4505`                      | `activerecord/src/encryption/encryptor.ts` (`force_encoding_if_needed`, `encryptor.rb:166`)                                                                                                                                                                                                                                                                                                                   |
| `rbFArray`                                                              | `object.c:3825` `rb_f_array`                                             | `actionpack/src/action-controller/metal/params-wrapper.ts` (`Options.from_hash`'s `Array(hash[:format])`, `params_wrapper.rb:90-92`)                                                                                                                                                                                                                                                                          |
| `Open3.capture2e`, `Process.Status`                                     | `lib/open3.rb:902`, `process.c:9169` `rb_cProcessStatus`                 | `Thor::Actions#run`'s `capture:` arm (`actions.rb:265-266`), same story                                                                                                                                                                                                                                                                                                                                       |
| `URI::Generic#opaque` / `opaque=` / `user` / `password` / `hostname`    | `lib/uri/generic.rb:277,916,568,573,668`                                 | `activerecord/src/database-configurations/connection-url-resolver.ts` (`ConnectionUrlResolver#initialize`, `#raw_config`)                                                                                                                                                                                                                                                                                     |
| `rbHashSRuby2KeywordsHashP` / `rbHashSRuby2KeywordsHash`                | `hash.c:1952,1974` `rb_hash_s_ruby2_keywords_hash(_p)`                   | `ActiveJob::Arguments` (`serialize_argument`'s `Hash.ruby2_keywords_hash?(argument)`, `deserialize_hash`'s `Hash.ruby2_keywords_hash(result)`, `vendor/rails/v8.0.2/activejob/lib/active_job/arguments.rb:93,154`), no caller yet: story `port-ruby-compat-ruby2-keywords-hash-flag` (RFC 0169) lands the primitive ahead of `port-activejob-arguments`, which ports those two lines                          |
| `PP` (`PP.pp`, `#pp`, `#seplist`, `#objectAddressGroup`, …)             | `lib/pp.rb:64,95,189,216,255`                                            | `activerecord/src/core.ts` (`Core#pretty_print`), `relation.ts` (`Relation#pretty_print`), `associations/collection-proxy.ts`; `PP.pp` from `core.test.ts`, `relations.test.ts`, `filter-attributes.test.ts`, `associations.test.ts`                                                                                                                                                                          |
| `PrettyPrint` (`#text`, `#breakable`, `#group`, `#nest`, `#flush`)      | `lib/prettyprint.rb:34,182,226,251`                                      | `PP`'s superclass; `activerecord/src/core.ts` (`pp.text` / `pp.breakable` / `pp.group` in `Core#pretty_print`)                                                                                                                                                                                                                                                                                                |
| `Set` (`#add`, `#delete`, `#has`, `#clear`, `#subtract`)                | `lib/set.rb:243,316,393,511,529,609`                                     | `activerecord/src/associations/preloader/association.ts` (`LoaderRecords`' `@keys_to_load = Set.new` and `subtract`, `preloader/association.rb:64,88`)                                                                                                                                                                                                                                                        |
| `rbDefineInspectCustom`                                                 | `io.c:9023` `rb_p` (prints `rb_inspect`)                                 | `activerecord/src/connection-adapters/abstract/connection-pool.ts`, `abstract-adapter.ts`, `encryption/cipher/aes256-gcm.ts`                                                                                                                                                                                                                                                                                  |

### Core classes are class objects; `Symbol` is seated but classifies nothing

`rbObjClass` answers `Object#class` as a class object. `NilClass`, `TrueClass`,
`FalseClass`, `Numeric`, `Integer`, `Float`, `String`, `Class`, `Proc`, `Time`,
`Date`, `DateTime` and `BasicObject` are seated in `object.ts` by
`rb_define_class`; `Hash`, `Module`, `Kernel` and `Enumerable` are the exports
of those names. `include.ts` wires their MRI included modules.

`Symbol` is seated as a constant, `rbCSymbol` (`string.c:12290`,
`rb_define_class("Symbol", rb_cObject)`), so `rbPathToClass("Symbol")` answers
it: `Psych::ClassLoader#symbolize` calls its `symbol` reader, which is
`path2class("Symbol")` (`ext/psych/lib/psych/class_loader.rb:31-43,51-56`), and
`ClassLoader::Restricted#find` raises `DisallowedClass` unless `'Symbol'` is
permitted (`:92-98`). No JS value is an instance of it. A Ruby Symbol is a bare
JS string everywhere except the call sites that keep its colon to tell it from
a String, so no reading of a value can answer "is a Symbol": a classifier keyed
on the colon would call `"::1"` and `"::Float::NAN"` Symbols. `rbObjClass`
answers `String` for every string, and a call site that discriminates uses
`isSymbol`; `rbObjIsKindOf(obj, rbCSymbol)` is that same `isSymbol` reading.

| Seat        | MRI                           | Called by                                                                                   |
| ----------- | ----------------------------- | ------------------------------------------------------------------------------------------- |
| `rbCSymbol` | `string.c:12290` `rb_cSymbol` | `ruby-compat/lib/variable.ts` (the `Symbol` core seat, read by `Psych::ClassLoader#symbol`) |

### Keyword arguments are a flagged trailing hash

Ruby marks a method `ruby2_keywords` so that the keywords it was called with
arrive as a trailing Hash in `*args`, flagged to be passed on as keywords.
`ActiveJob::Core#initialize` and `Enqueuing::ClassMethods#job_or_instantiate`
are marked that way
(`vendor/rails/v8.0.2/activejob/lib/active_job/core.rb:103`,
`enqueuing.rb:94`), and `Arguments` reads and restores the flag across
serialization (`arguments.rb:93-97,153-155`).

JS has no keyword arguments, so a call site cannot tell `perform_later(k: 1)`
from `perform_later({ k: 1 })`. This is the repo's kwargs idiom, a trailing
options object, applied to a `ruby2_keywords` method. The rule is: **a trailing plain-object argument
to `performLater` / `new` is the kwargs hash.** The port of a `ruby2_keywords`
method flags it with `rbHashSRuby2KeywordsHash` before storing its arguments,
which is what the VM does for the Ruby method, and everything downstream asks
`rbHashSRuby2KeywordsHashP` exactly where Rails asks
`Hash.ruby2_keywords_hash?`.

This rule is recorded here by story `port-ruby-compat-ruby2-keywords-hash-flag`
(RFC 0169, the ActiveJob port), which assigns it to this README. Its callers
are `port-activejob-core` and `port-activejob-enqueuing-and-configured-job`.

The flag is membership in a module-private `WeakSet`, as MRI's is a bit in the
hash's own header (`RHASH_PASS_AS_KEYWORDS`, `internal/hash.h:23`). It is not a
property, so `Object.keys`, a spread and `JSON.stringify` never see it, and a
copy of a flagged hash is unflagged.

### When a Ruby Hash is a `Hash` and when it is an object

A Ruby Hash is a plain JS object. It is a `Hash` (`hash.ts`, `extends Map`)
only where the site needs one of the features below, none of which an object
can hold. The class is permanent for these and is not convergence debt. That
does not license a `new Hash()` where Rails has a string-keyed `{}`.

| feature                                    | field                 | MRI anchor                                                                                        | a trails call site                                                                                                                                                                     |
| ------------------------------------------ | --------------------- | ------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| the `default` seat, `Hash.new(obj)`        | `#default`            | `hash.c:1782` `rb_hash_initialize`, `hash.c:2068` `rb_hash_default_value`                         | `activerecord/src/associations/has-many-through-association.ts:90` (`Hash.new(0)`, `has_many_through_association.rb:194`)                                                              |
| the `default_proc` seat, `Hash.new { }`    | `#defaultProc`        | `hash.c:2308` `rb_hash_set_default_proc`                                                          | `activerecord/src/associations/join-dependency.ts:275` (`Hash.new { \|h, klass\| h[klass] = {} }`, `join_dependency.rb:114`)                                                           |
| key equality by `eql?` / `hash`            | `#eqlKeys`, `#stHash` | `hash.c:126` `rb_any_cmp`, `hash.c:171` `any_hash`; Array keys: `array.c:5165,5205`               | `activerecord/src/connection-adapters/deduplicable.ts:27` (`registry[self]`, `deduplicable.rb:9-19`); Array keys: `actionview/src/renderer/partial-renderer/collection-caching.ts:114` |
| a binary String key `eql?` to a 7-bit one  | `#binaryKeys`         | `string.c:3773` `rb_str_eql`, `string.c:3629` `rb_str_hash`                                       | none outside `hash.ts`; pinned by `hash.trails.test.ts:204`                                                                                                                            |
| `compare_by_identity`                      | `#identhash`          | `hash.c:4427` `rb_hash_compare_by_id`                                                             | `activerecord/src/associations/preloader/association.ts:133` (`{}.compare_by_identity`, `preloader/association.rb:200`)                                                                |
| `FL_FREEZE` on the hash, a `FrozenError`   | `#frozen`             | `hash.c:105` `rb_hash_freeze`, `hash.c:1602` `rb_hash_modify_check`                               | `activemodel/src/errors.ts:164,174` (`hash.freeze`, `errors.rb:271,281`)                                                                                                               |
| the iteration level, a write during `each` | `#iterLev`            | `hash.c:1345` `hash_iter_lev_inc`, `hash.c:1630` "can't add a new key into hash during iteration" | none outside `hash.ts`; every `for…of` over a `Hash` raises it, pinned by `hash.trails.test.ts:1019`                                                                                   |

`#binaryKeys` is not a feature of its own. It is the flag that keeps a String
lookup off the `eql?` buckets until a `Uint8Array` key has been stored, so it
belongs to the key-equality row and is listed apart only because it is a field.

A key that is a string needs none of this: a JS object already compares string
keys by value. Reach for `Hash` when the key is an object, an Array or a number
that must stay a number, or when the site sets a default, freezes the hash or
compares by identity. Otherwise write `{}`.

### The hash helpers are for the arms JS lacks

A Hash call on a plain object is written as the JS form: `k in h` /
`Object.hasOwn(h, k)`, `h[k]`, `h[k] = v`, `delete h[k]`,
`Object.assign(h, other)`, `{ ...h, ...other }`, and
`for (const [k, v] of Object.entries(h))`. The call gates credit each form
(`NATIVE_FORM_ANALOGUES`, `scripts/api-compare/enumerable-idioms.ts`). The
helpers in `hash.ts` stay for what those forms cannot do:

| helper                 | MRI anchor                        | the arm JS has no form for                                                                                |
| ---------------------- | --------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `hasKey`               | `hash.c:3671` `rb_hash_has_key`   | dispatch to a `Map`, a `Hash` or an `isKey` member; an `undefined`-valued keyword read as absent          |
| `hashAref`             | `hash.c:2121` `rb_hash_aref`      | a miss that answers `null`; a `Hash` default; a computed key that could name an `Object.prototype` member |
| `hashAset`             | `hash.c:2941` `rb_hash_aset`      | a caller-supplied `"__proto__"` key; `FrozenError`; a `Map` or `set` receiver                             |
| `hashDelete`           | `hash.c:2441` `rb_hash_delete_m`  | the removed value as the result; the miss block; `FrozenError`                                            |
| `mergeBang` / `update` | `hash.c:4028` `rb_hash_update`    | the conflict block; a `Map` on either side                                                                |
| `merge`                | `hash.c:4144` `rb_hash_merge`     | the conflict block; a result with no prototype, so `__proto__` is an ordinary key                         |
| `eachPair`             | `hash.c:3149` `rb_hash_each_pair` | a `Map` or `each` receiver; the receiver as the call's result                                             |
| `fetch`                | `hash.c:2176` `rb_hash_fetch_m`   | all of it: a stored `nil` beats the default, and a miss with no default raises `KeyError`                 |
| `deleteIf` / `keepIf`  | `hash.c:2564`, `hash.c:2844`      | all of it: an in-place filter with Ruby truthiness on the block result                                    |
| `hashReplace`          | `hash.c:2967` `rb_hash_replace`   | all of it: clear-then-copy with a `FrozenError`                                                           |

A site that needs none of those arms uses the form, and an arm with no caller
left is deleted under rule 1.

## The contract

Four rules govern this package. Rules 2 and 3 are mechanically enforced, rule 4
is structural, and rule 1 is enforced by review until its gate lands (see
below).

### 1. Only what trails actually calls

No member exists here without a real call site elsewhere in this repo, and one
call site is not enough (RFC 0194). A helper earns its place with one of three
things: **two or more importing files**, **object-model state** (constant
tables, ivar seats, module records), or **an adapter seam** (RFC 0135). A
helper with one importing file and neither of the others is inlined at that
caller, reduced to the subset the caller reaches. This is
not a general-purpose Ruby runtime, and it is not a place to port a method
because its siblings are already here — `String#succ` earns its keep because
`arel` calls it; `String#squeeze` does not, until something calls it.

Today this rule is enforced by review, not by a gate: the question a reviewer
asks of a new export is "where is the call site", the answer must be a file and
a line, and it goes in the table above. Mechanical enforcement is
`ruby-compat-rule-1-call-site-gate`.

The extra-surface counter does NOT enforce it, although earlier revisions of
this README said it did. `ruby-compat` is in `GATED_PACKAGES`
(`scripts/api-compare/extra-surface-mark.ts`) with its mark committed in
`extra-surface-mark.json`, and `pnpm parity:api:extra:gate` fails on any
increase in either dimension. But the counter subtracts every member carrying a
`@noRailsEquivalent` receipt, and rule 2 requires that receipt on every export,
so a correctly receipted member — speculative or not — never reaches it.

### Growing the package: the receipt is the protocol

For a Rails package extra surface is debt and only-shrink is the whole point.
Here it is inventory: every move story adds MRI surface. The two do not
conflict, because growth here is **mark-neutral**:

- A member that arrives with its rule 2 receipt is subtracted from `novel` AND
  `total`, whether its name is novel or collides with a Rails method in some
  other `.rb` and would score moved. Adding it moves neither number.
- A member that arrives WITHOUT its receipt raises `total` (and, if novel,
  trips the `novel === 0` pin), and the gate turns red. The fix is the
  receipt, never a bigger mark.

So there is no raise path, and none is needed: the mark stays only-shrink
(`parity:api:extra:tighten` writes it DOWN) with **no reseed**, exactly as for
every other gated package. The `total` it holds today is the residue of members
that never got their receipt, a rule 2 violation burnt down by
`receipt-ruby-compat-moved-residue`.

### Native first: the helper families kept on purpose

Where the native JS form is identical at a call site, the helper is wrong, not
optional (RFC 0194, owner ruling 2026-10-19); `ruby-compat-native-required`
enforces it for the helpers in `eslint/ruby-compat-native-required.json`. These
families are kept on purpose, with no substitution story:

- **The object model**: `include` / `extend` / `defineModule`, `rbObjDup` /
  `rbObjClone`, the singleton class, constants, and `rbFSend` /
  `rbObjRespondTo` for a computed name or a `method_missing` receiver.
- **The Hash semantics JS lacks**: `fetch` where the key is computed or one
  argument or a block is passed (the two-argument literal-key arm on a plain
  object is `Object.hasOwn(h, "k") ? h.k : default`), `deleteIf` / `keepIf` /
  `hashReplace`, and the `Hash` class for the features listed above.
- **Exceptions and Kernel**: the error classes, `excSetupMessage`, `rbFLoad`,
  `block()` / `rbBlockGivenP`, and `toEnum`.
- **`rbInspect`**, for a message Ruby renders with `inspect`.
- **`rtest`, `isSymbol` and `symbolToS`**, which cost the same as native and
  are the sanctioned spellings.

Any other helper survives only at a site where it dispatches (a `Map` / `Hash`
receiver, a receiver answering the call itself, a computed name) or where its
semantics observably differ.

**Enumerable is free functions.** `enumerable.ts` exports each method as a
function taking the receiver first — `partition(enum, fn)`, `groupBy(enum,
fn)`, `eachSlice(enum, n, fn)` — and dispatches on an `each` receiver, an
iterable or a `Range`. Nothing is installed on `Array.prototype`. On an Array
whose block result is a boolean, the native method is the form.

### 2. Every export carries BOTH a `vendor/ruby` citation and a receipt

Each exported member needs two things in its JSDoc:

- a `vendor/ruby/<version>/<file>:<line>` citation naming the MRI source it mirrors, and
- a `@noRailsEquivalent PERMANENT` receipt.

Both, always. They answer different questions and neither substitutes for the
other:

- The **citation** is the fidelity anchor. It says _this behavior is Ruby's, and
  here is where to check it_. Without it a Ruby primitive degrades into a
  hand-rolled utility, and the next contributor has no way to tell a faithful
  `succ` from an approximation of one. It is the `vendor/rails` citation every
  other package writes, pointed at the other upstream.
- The **receipt** is the parity bookkeeping. `@noRailsEquivalent` is what marks
  a public name that has no Ruby-_Rails_ counterpart, and every name here is one
  — that is the definition of this package. `PERMANENT` is the correct
  permanence: these members will never converge onto a Rails method, because
  there is no Rails method to converge onto. A `CONVERGEABLE <story-id>` receipt
  here is a category error, not a smaller version of the same claim.

So a citation without a receipt fails the extra-surface tooling, and a receipt
without a citation passes the tooling while losing the only record of what the
code is supposed to do. Write both.

Both are enforced by `blazetrails/ruby-compat-needs-mri-citation`
(`eslint/ruby-compat-needs-mri-citation.mjs`), which RESOLVES the citation
rather than pattern-matching it: the file has to exist under `vendor/ruby/` at
the pinned SHA and the line has to be within it. The vendor tree is fetched
rather than committed, so the rule skips where it is absent — the
`rails-comparison` CI job, which fetches it, is the enforcing run. The reverse
direction is covered too: this package is in the RFC 0121
`unbacked-internal-needs-receipt` enrollment set, because every member here is
absent from the rails-private manifest by construction.

And a primitive lives here ONCE.
`blazetrails/no-ruby-compat-reimplementation` fails a function or class declared
outside this package whose name is a ruby-compat export, or a registered alias
of one (`escapeRegExp` for `Regexp.escape`, a local `fetch(hash, key, default)`
over a `Record` for `Hash#fetch`, ...). Today's copies each hold one row in
`eslint/no-ruby-compat-reimplementation-exclude.json`, which is only-shrink: a
row is deleted by the move story that converges it, and a new row is never the
remedy for new code.

That is enforced, not merely conventional.
`eslint/no-ruby-compat-reimplementation-mark.mjs` gates the register against the
committed high-water mark in
`eslint/no-ruby-compat-reimplementation-mark.json` — the way
`extra-surface-mark.json` gates extra surface — and fails when the array holds
more rows than the mark, or is not sorted (an appended row reads correctly to
the rule, so nothing else says where it belongs). Its `tighten` path writes the
mark DOWN as the move stories delete rows; there is no reseed.

### 3. `parity:api` never enrolls this package — permanently

`parity:api`'s package list is derived from `vendor/sources.ts` via
`apiComparePackages()` (`scripts/api-compare/config.ts`), and its population is
Rails gems. `ruby-compat` has no gem counterpart there and never will: it is a
port of Ruby, and Rails-parity comparison over it is meaningless — there is
nothing on the other side to compare against.

This is not a deferral awaiting a story, and it is not a `SKIP_GROUPS` entry
with a burndown behind it. Do not add `ruby-compat` to `vendor/sources.ts`, to
`PACKAGES`, or to `PACKAGES_OUTSIDE_MANIFEST` — the last of those subtracts a
package from the `unbacked-internal-needs-receipt` rule, and this package wants
that rule at full strength (rule 2 requires the receipt unconditionally).

What it IS in is `TS_ONLY_PACKAGES` (same file) — the packages the TypeScript
extractor walks and the Rails comparison never scores. That is the whole of the
enrollment rule 1 relies on: the TS manifest has to carry the package for the
extra-surface counter to see it, while the Rails-parity population stays a list
of gems.

### 4. It is a leaf: no workspace dependencies

`ruby-compat` depends on nothing in this workspace, and everything may depend on
it. In particular it must never depend on `@blazetrails/activesupport` — that
edge is the exact inversion the package exists to remove, and re-adding it would
put the cycle back.

`package.json` has no `dependencies` block and no workspace dependency of any
kind. The single `optionalDependencies` entry (`yaml`) is the npm backend of a
Ruby C extension (Psych's `psych.so`), reached only through its seam,
`psych-adapter.ts`. Keep it that way; if a primitive
here appears to need a trails module, the primitive is not a Ruby primitive.
