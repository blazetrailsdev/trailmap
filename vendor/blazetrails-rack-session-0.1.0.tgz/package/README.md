# @blazetrails/rack-session

A session implementation for Rack. It is the trails port of the `rack-session`
gem.

`rack-session` is not part of the Rails monorepo. Its upstream is
[rack/rack-session](https://github.com/rack/rack-session), vendored at
`vendor/rack-session/v2.1.0/` (RFC 0133). It is the anchor for ActionDispatch's
session middleware, the same way `vendor/rails/` is the anchor for every
framework package. `ActionDispatch::Session::CookieStore` subclasses
`AbstractSecureStore`, which subclasses `Rack::Session::Abstract::PersistedSecure`
(`vendor/rails/v8.0.2/actionpack/lib/action_dispatch/middleware/session/abstract_store.rb:97`),
so the base classes need a port of their own, not scaffolding inside actionpack.

## What is ported

| gem                               | trails               | status                                                                                                                                                                             |
| --------------------------------- | -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `lib/rack/session/abstract/id.rb` | `lib/abstract/id.ts` | Ported: `SessionId`, `SessionHash`, `Persisted`, `PersistedSecure` (with its `SecureSessionHash`) and `DEFAULT_OPTIONS`. `ActionDispatch::Session::AbstractStore` builds on these. |
| `lib/rack/session/pool.rb`        | `lib/pool.ts`        | Ported: `Rack::Session::Pool`, the in-memory store.                                                                                                                                |
| `lib/rack/session/constants.rb`   | none                 | `RACK_SESSION` and `RACK_SESSION_OPTIONS` are read from `@blazetrails/rack`'s constants. `RACK_SESSION_UNPACKED_COOKIE_DATA` is used only by the unported cookie store.            |
| `lib/rack/session/cookie.rb`      | none                 | Not ported, by decision (RFC 0133 non-goal). Rails' `CookieStore` does not use `Rack::Session::Cookie`. Its tests are `PERMANENT-SKIP` stubs.                                      |
| `lib/rack/session/encryptor.rb`   | none                 | Not ported, same reason: it serves only `Rack::Session::Cookie`.                                                                                                                   |

As of 2026-09-27, `parity:api` credits 50 of 60 public methods, and
`parity:test` matches 58 of the gem's 124 tests. The other 66 are the
`PERMANENT-SKIP` stubs for the two files above.

```ts
import { Pool, Persisted, SessionId } from "@blazetrails/rack-session";
```

Application code normally reaches these through ActionDispatch's session
stores, not directly.

## The contract

- **The vendored gem is the source of truth.** Read
  `vendor/rack-session/v2.1.0/lib/rack/session/<file>.rb` before writing
  anything here, the same way every other package reads `vendor/rails/` first.
- **Every member cites its anchor.** A ported member carries a
  `vendor/rack-session/v2.1.0/lib/rack/session/<file>.rb:LINE` citation, so a
  reviewer can put the Ruby and the TypeScript side by side.
- **Both parity gates run over it.** Unlike `date` and `minitest`, whose Ruby
  side is C or is not compared at all, `rack-session` is pure Ruby with a real
  test suite at `vendor/rack-session/v2.1.0/test/`, so `parity:api` and
  `parity:test` both measure this package.
- **Workspace dependencies follow the gemspec.** The gemspec declares
  `rack >= 3.0.0` (`vendor/rack-session/v2.1.0/rack-session.gemspec:24`), and
  the code uses `Rack::Request`, `Rack::Utils.set_cookie_header` and
  `Rack::Response`, so `@blazetrails/rack` is the one framework dependency. The
  other is `@blazetrails/ruby-compat`, the leaf every package may use for Ruby
  core. Nothing else in the workspace may be depended on from here.

## Source layout

`lib/**` mirrors `lib/rack/session/**` under the gem's module root, matching how
`packages/rack/src/**` mirrors `lib/rack/**`. A new file lands at the path the
table above gives it.
